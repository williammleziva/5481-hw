The Program can be exectued with the command 
    python3 NeiSaitou.py -i hw3.fna 
where -i marks the fasta input file 