The program can be run with python, the data file is hardcoded in the program, so no inputs are needed

python3 hw4.py 

